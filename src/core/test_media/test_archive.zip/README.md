Title is all that is needed. Give it through the dev console.
